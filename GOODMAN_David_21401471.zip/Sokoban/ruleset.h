/*
 * Nom:			GOODMAN
 * PRENOM:		David
 * # ETUDIANT:	21401471
*/

#ifndef RULESET_DEF
#define RULESET_DEF

#endif
