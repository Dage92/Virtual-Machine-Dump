/*
 * Nom:			GOODMAN
 * PRENOM:		David
 * # ETUDIANT:	21401471
*/

#include <stdlib.h>
#include <stdio.h>
#include <uvsqgraphics.h>
#include "constants.h"
#include "ruleset.h"
